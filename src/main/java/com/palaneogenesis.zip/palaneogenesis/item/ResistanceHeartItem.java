package com.palaneogenesis.item;

import com.palaneogenesis.capability.HeartType;
import com.palaneogenesis.config.Config;
import com.palaneogenesis.util.HeartArray;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Resistance Heart (Blue_Hearts.md): ½ corazón de vida. Mientras el jugador tenga puntos de este
 * tipo en el array otorga Prisa Minera según la tabla del diseño (ver
 * event.HeartEvents#onPlayerTick); al romperse otorga Resistencia II (ver
 * event.HeartEvents#triggerBreak).
 */
public class ResistanceHeartItem extends Item {

	public ResistanceHeartItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);

		if (!level.isClientSide) {
			HeartArray.addPoints(player, HeartType.RESISTANCE, Config.COMMON.resistanceHeartPoints.get());
		}

		player.awardStat(Stats.ITEM_USED.get(this));
		if (!player.getAbilities().instabuild) {
			stack.shrink(1);
		}

		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
	}
}
